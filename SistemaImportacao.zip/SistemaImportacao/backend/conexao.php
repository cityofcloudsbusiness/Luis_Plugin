<?php 
	$con = mysqli_connect("localhost","admin_plugin","EC3QZ-DJMD2","admin_p24h");

 ?>