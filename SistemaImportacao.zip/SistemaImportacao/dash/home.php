<link rel="stylesheet" href="css/home.css">

<div id="odin">
    <div class="titulo">SISTEMA DE CADASTRO DE ALTERAÇÕES EM MASSA</div>
    <div class="pai">
        <ul>
            <li style="--i:6;"><a href="#">Home</a></li>
            <li style="--i:5;"><a href="#">Import Excel</a></li>
            <li style="--i:4;"><a href="#">Codificando</a></li>
            <li style="--i:3;"><a href="#">Metas Descrições Prod.</a></li>
            <li style="--i:2;"><a href="#">Metas Descrições Cat.</a></li>
            <li style="--i:1;"><a href="#">Preços Produtos</a></li>
        </ul>
        <ul>
            <li style="--i:6;"><a href="#">Config Marca</a></li>
            <li style="--i:5;"><a href="#">Config Cat & Pro</a></li>
            <li style="--i:4;"><a href="#">Converter Cat p/ Prod</a></li>
            <li style="--i:3;"><a href="#">Acres.Nome F/Titulo</a></li>
            <li style="--i:2;"><a href="dash/Importacao_Exportacao.php">Import/Export B.D</a></li>
            <li style="--i:1;"><a href="#">Contact</a></li>
        </ul>
    </div>
</div>